﻿namespace TelegramBot.Service.TelegramBot.Interfaces
{
    public interface ITelegramBotService
    {
        Task StartAsync(CancellationToken cancellationToken);
    }
}
﻿namespace TelegramBot.Service.Weather.Interfaces
{
    public interface IWeatherService
    {
        Task<string> GetWeatherAsync(string cityName);
    }
}

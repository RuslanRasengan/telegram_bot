﻿namespace TelegramBot.Service.OpenAi.Interfaces
{
    public interface IOpenAiService
    {
        Task<string> GetResponseAsync(string userInput);
    }
}
